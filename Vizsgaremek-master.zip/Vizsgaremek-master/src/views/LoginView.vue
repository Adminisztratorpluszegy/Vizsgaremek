<template>
    <section>
        <RouterLink to="/">
            <img id="BackArrow" src="../assets/BackArrow.ico">
        </RouterLink>
        <VForm>
        <div class="container text-center">
            <h2>Bejelentkezés</h2><br>
            <Field name="username" placeholder="  Felhasználónév" rules="required|username" class="input-field"/>
            <ErrorMessage name="username" class="error-text" /><br><br>
            <Field id="PasswordPlace" name="password"  type="password" rules="required|password" placeholder="  Jelszó" class="input-field" />
            <ErrorMessage name="password" class="error-text" />
            <br>
            <p>Nincs fiókja:</p>
            <RouterLink to="/register"> <p id="Link">Kattintson ide</p> </RouterLink>
            <br>
            <button type="submit" class="btn">Bejelentkezés</button>
        </div>
        </VForm>
    </section>
</template>

<script>
import  {Form as VForm, Field, ErrorMessage} from "vee-validate";
import { RouterLink } from 'vue-router';
export default {
    components:{
    RouterLink,
    VForm,
    Field,
    ErrorMessage
},

}
</script>

<style scoped>
.error-text {
    color: white;
    position: absolute;    
}

#Link{
    text-decoration: underline;
    text-decoration-color: gray;
}

#PasswordPlace{
    position: relative;
    bottom: 8px;
}

p{
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    font-size: 11pt;
    color: white;
    position: relative;
    top: 5px;
    right: 45px;
    display: inline-block;
    margin-right: 10px;
    color: gray;
}

#BackArrow{
    position: absolute;
    top: 20px;
    left: 25px;
    width: 50px;
    height: min-content;
}

h2 {
    color: #c4c2c2;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}

::placeholder {
    color: gray;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}

button:hover {
    color: grey;
    background-color: #1f1d1c;
}

button {
    position: relative;
    top: 20px;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    width: 300px;
    height: 43px;
    color: white;
    border-radius: 12px;
    background-color: #36322f;
}

.input-field {
    width: 300px;
    height: 40px;
    border-radius: 8px;
    background-color: #171615;
    color: white;
}

div {
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
}

section {
    background-image: url("../assets/Register_Login_Background.jpeg");
    background-repeat: no-repeat;
    background-position: center;
    background-size: cover;
    height: 100vh;
}
</style>
