<template>
<h1>Főoldal</h1>
<img id="First_Img" src="/src/assets/HomeV_1.jpeg">
</template>

<script>
export default {
    name: 'IndexView'
}
</script>

<style scoped>
h1{
    position: absolute;
    z-index: 1;
    color: white;
    width: 100%;
    text-align: center;
}

#First_Img{
    border-radius: 12px;
    width: 100%;
    height: auto;
    position: relative;
}



</style>
