<template>
  <nav class="navbar navbar-expand-lg bg-body-tertiary" id="nav">
    <div class="container-fluid">
      <router-link class="navbar-brand" to="/" active-class="active"><img id="Logo" src="/src/assets/Logo.png"></router-link>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
        aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
        <ul class="navbar-nav">
          <li class="nav-item">
            <router-link class="nav-link" to="/register" active-class="active">Regisztráció</router-link>
          </li>
          <li class="nav-item">
            <router-link class="nav-link" to="/login" active-class="active">Bejelentkezés</router-link>
          </li>
        </ul>
      </div>
    </div>
  </nav>
</template>

<script>
import { RouterLink } from 'vue-router'
export default {
  name: 'NavBar',
  components: {
    RouterLink
  },

}
</script>

<style>

#nav a {
  font-weight: bold;
  position: relative;
  top: 5px;
  color: white;
  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}

#Logo {
  width: 170px;
  height: 50px;
  content: url(/src/assets/Logo.png);
}

.active #Logo {
  content: url(/src/assets/BlackLogo.png);
  width: 170px;
  height: 50px;
}

.navbar-brand {
  position: absolute;
  text-align: right;
  width: 180px;
  margin: auto;
}

#nav {
  background-image: url(/src/assets/NavBarBackGround.jpg);
}

#nav a.active {

  color: black;
  border-radius: .7rem;
  background-color: white;

}
</style>
